# Welcome to yFiles for HTML 3.1.0.2!

[yFiles for HTML](https://www.yfiles.com/the-yfiles-sdk/web/yfiles-for-html) is a powerful diagramming library that enables you to create
**interactive, high-performance graph visualizations** for web applications.

With a **comprehensive API**, yFiles provides advanced features such as:

- Customized graph designs
- Automatic layouts
- Intuitive user interactions
- Seamless data integration

Integrate yFiles into your existing apps, dashboards, and reports, or start creating new stunning
apps with it right away!

## Getting Started

New to yFiles for HTML? Check out these resources:

- [Getting Started—Developer's Guide](https://docs.yworks.com/yfileshtml/dguide/getting_started) – A comprehensive introduction.
- [Getting Started—Video](https://youtu.be/_1VGRYsslNo?si=h_AXVDynJ1pWM_rw) – A hands-on walkthrough.

## Demo Applications

The yFiles for HTML library includes a vast collection of **demo applications and tutorials**,
available in **JavaScript and TypeScript**. You can find the source code in the `demos-js` and `demos-ts`
folders of the download package.

To get started, follow the [Guide to Run Demos](https://docs.yworks.com/yfileshtml/dguide/demos-usage).

All demo source code is also available on [GitHub](https://github.com/yWorks/yfiles-for-html-demos).

## Documentation & Resources

Find detailed documentation and tutorials here:

- 📖 [Developer’s Guide & API Documentation](https://docs.yworks.com/yfileshtml/dguide/introduction-about_dguide) – All you need to know as a developer.
- 🎥 [yFiles for HTML Playlist](https://www.youtube.com/playlist?list=PLpIlEtPgrZsU4icTnBORqSV23tLVvPObd) – Learn by watching!

## License Terms

Using yFiles for HTML requires a **valid license**. Please ensure compliance with the
[yFiles for HTML License Agreement](https://www.yworks.com/products/yfiles-for-html/sla) before using this package.

## Need Help?

If you get stuck, don’t hesitate to reach out via the [yWorks Customer Center](https://my.yworks.com)

email at [yfileshtml@yworks.com](mailto:yfileshtml@yworks.com).

Happy diagramming with **yFiles for HTML**! 🎉
