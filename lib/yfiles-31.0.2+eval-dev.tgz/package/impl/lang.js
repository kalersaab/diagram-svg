/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 3.1.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2026 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/

import e from"./lang-dev.js";import o from"./lang-prod.js";const n="undefined"!=typeof window?window:"undefined"!=typeof global?global:self,p=n.process;let d;p&&"object"===typeof p.env||(n.process={env:{}}),d="production"!==process.env.NODE_ENV?e:o,"undefined"!==typeof p&&(n.process=p);export default d;