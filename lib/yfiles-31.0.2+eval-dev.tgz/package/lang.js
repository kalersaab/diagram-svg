/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 3.1.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2026 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/

import e from"./impl/lang.js";export const BaseClass=e.BaseClass;export const Class=e.Class;export const ClassDefinition=e.ClassDefinition;export const Enum=e.Enum;export const EnumDefinition=e.EnumDefinition;export const Exception=e.Exception;export const IComparable=e.IComparable;export const Interface=e.Interface;export const InterfaceDefinition=e.InterfaceDefinition;export const License=e.License;export const delegate=e.delegate;export const yfiles=e.yfiles;