/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 3.1.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2026 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/

import r from"./impl/layout-circular.js";export var CircularLayout=r.circular.CircularLayout;export var CircularLayoutData=r.circular.CircularLayoutData;export var CircularLayoutEdgeDescriptor=r.circular.CircularLayoutEdgeDescriptor;export var CircularLayoutExteriorEdgeDescriptor=r.circular.CircularLayoutExteriorEdgeDescriptor;export var CompactDiskLayout=r.circular.CompactDiskLayout;export var CompactDiskLayoutData=r.circular.CompactDiskLayoutData;export var CircularLayoutEdgeRoutingPolicy=r.circular.CircularLayoutEdgeRoutingPolicy;export var CircularLayoutOnCircleRoutingStyle=r.circular.CircularLayoutOnCircleRoutingStyle;export var PartitionDescriptor=r.circular.PartitionDescriptor;export var CircularLayoutPartitionStyle=r.circular.CircularLayoutPartitionStyle;export var CircularLayoutPartitioningPolicy=r.circular.CircularLayoutPartitioningPolicy;export var CircularLayoutRoutingStyle=r.circular.CircularLayoutRoutingStyle;export var CircularLayoutStarSubstructureStyle=r.circular.CircularLayoutStarSubstructureStyle;export var ChannelOrientation=r.router.ChannelOrientation;export var ChannelRoutingTool=r.router.ChannelRoutingTool;export var CurveRoutingEdgeDescriptor=r.router.CurveRoutingEdgeDescriptor;export var CurveRoutingStage=r.router.CurveRoutingStage;export var CurveRoutingStageData=r.router.CurveRoutingStageData;export default r;