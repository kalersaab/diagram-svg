/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 3.1.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2026 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/

import t from"./impl/layout-multi-page.js";export var MultiEdgeConnectorPolicy=t.multipage.MultiEdgeConnectorPolicy;export var MultiPageEdgeType=t.multipage.MultiPageEdgeType;export var MultiPageElementFactory=t.multipage.MultiPageElementFactory;export var MultiPageGroupingPolicy=t.multipage.MultiPageGroupingPolicy;export var MultiPageLayoutResult=t.multipage.MultiPageLayoutResult;export var MultiPageLayout=t.multipage.MultiPageLayout;export var MultiPageLayoutContext=t.multipage.MultiPageLayoutContext;export var MultiPageLayoutData=t.multipage.MultiPageLayoutData;export var MultiPageNodeType=t.multipage.MultiPageNodeType;export default t;