/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 3.1.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2026 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/

import o from"./impl/layout-orthogonal.js";export var OrthogonalLayoutChainSubstructureStyle=o.orthogonal.OrthogonalLayoutChainSubstructureStyle;export var OrthogonalLayoutCycleSubstructureStyle=o.orthogonal.OrthogonalLayoutCycleSubstructureStyle;export var OrthogonalLayout=o.orthogonal.OrthogonalLayout;export var OrthogonalLayoutData=o.orthogonal.OrthogonalLayoutData;export var OrthogonalLayoutEdgeDescriptor=o.orthogonal.OrthogonalLayoutEdgeDescriptor;export var OrthogonalLayoutMode=o.orthogonal.OrthogonalLayoutMode;export var SubstructureOrientation=o.orthogonal.SubstructureOrientation;export var OrthogonalLayoutTreeSubstructureStyle=o.orthogonal.OrthogonalLayoutTreeSubstructureStyle;export default o;