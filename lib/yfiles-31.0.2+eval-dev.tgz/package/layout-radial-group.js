/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 3.1.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2026 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/

import a from"./impl/layout-radial-group.js";export var RadialGroupLayout=a.layout.RadialGroupLayout;export var RadialGroupLayoutData=a.layout.RadialGroupLayoutData;export default a;