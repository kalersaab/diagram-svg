/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 3.1.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2026 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/

import r from"./impl/layout-router.js";export var BundledEdgeRouter=r.router.BundledEdgeRouter;export var BundledEdgeRouterData=r.router.BundledEdgeRouterData;export var BundledEdgeRouterStrategy=r.router.BundledEdgeRouterStrategy;export var EdgeRouterBusDescriptor=r.router.EdgeRouterBusDescriptor;export var CellEntrance=r.router.CellEntrance;export var EdgeCellInfo=r.router.EdgeCellInfo;export var EdgeRouter=r.router.EdgeRouter;export var EdgeRouterData=r.router.EdgeRouterData;export var EdgeRouterScope=r.router.EdgeRouterScope;export var EdgeRouterScopeData=r.router.EdgeRouterScopeData;export var IRouterPartition=r.router.IRouterPartition;export var OctilinearRoutingStage=r.router.OctilinearRoutingStage;export var OrganicEdgeRouter=r.router.OrganicEdgeRouter;export var OrganicEdgeRouterData=r.router.OrganicEdgeRouterData;export var PartitionCell=r.router.PartitionCell;export var PartitionExtension=r.router.PartitionExtension;export var PathSearchConfiguration=r.router.PathSearchConfiguration;export var PathSearchContext=r.router.PathSearchContext;export var PathSearchExtension=r.router.PathSearchExtension;export var PathSearchRequest=r.router.PathSearchRequest;export var PathSearchResult=r.router.PathSearchResult;export var RoutingObstacle=r.router.RoutingObstacle;export var RoutingType=r.router.RoutingType;export default r;