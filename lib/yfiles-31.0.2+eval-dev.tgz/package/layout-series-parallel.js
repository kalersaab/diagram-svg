/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 3.1.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2026 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/

import e from"./impl/layout-series-parallel.js";export var ISeriesParallelLayoutPortAssigner=e.seriesparallel.ISeriesParallelLayoutPortAssigner;export var SeriesParallelLayoutPortAssignmentMode=e.seriesparallel.SeriesParallelLayoutPortAssignmentMode;export var SeriesParallelLayoutRoutingStyle=e.seriesparallel.SeriesParallelLayoutRoutingStyle;export var SeriesParallelLayout=e.seriesparallel.SeriesParallelLayout;export var SeriesParallelLayoutData=e.seriesparallel.SeriesParallelLayoutData;export var SeriesParallelLayoutEdgeDescriptor=e.seriesparallel.SeriesParallelLayoutEdgeDescriptor;export var SeriesParallelLayoutPortAssigner=e.seriesparallel.SeriesParallelLayoutPortAssigner;export default e;