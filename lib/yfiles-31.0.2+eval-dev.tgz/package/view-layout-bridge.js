/****************************************************************************
 ** @license
 ** This file is part of yFiles for HTML 3.1.0.2.
 **
 ** yWorks proprietary/confidential. Use is subject to license terms.
 **
 ** Copyright (c) 2026 by yWorks GmbH, Vor dem Kreuzberg 28,
 ** 72070 Tuebingen, Germany. All rights reserved.
 **
 ***************************************************************************/

import t from"./impl/view-layout-bridge.js";export var IntersectionsResult=t.analysis.IntersectionsResult;export var Intersection=t.analysis.Intersection;export var Intersections=t.analysis.Intersections;export var ExtendedEdgeLabelCandidate=t.layout.ExtendedEdgeLabelCandidate;export var ExtendedNodeLabelCandidate=t.layout.ExtendedNodeLabelCandidate;export var LabelPlacementPolicy=t.layout.LabelPlacementPolicy;export var LayoutExecutor=t.layout.LayoutExecutor;export var LayoutExecutorAsync=t.layout.LayoutExecutorAsync;export var LayoutExecutorAsyncWorker=t.layout.LayoutExecutorAsyncWorker;export var LayoutGraphAdapter=t.layout.LayoutGraphAdapter;export var InteractiveOrganicLayoutData=t.organic.InteractiveOrganicLayoutData;export var PortAdjustmentPolicy=t.layout.PortAdjustmentPolicy;export var PortLabelPolicy=t.layout.PortLabelPolicy;export var PortPlacementPolicy=t.layout.PortPlacementPolicy;export var TableLayoutConfigurator=t.layout.TableLayoutConfigurator;export default t;